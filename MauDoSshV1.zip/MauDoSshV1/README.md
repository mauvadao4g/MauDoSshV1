# SSH-PLUS

# @donomodderajuda

PROJETO EM ANDAMENTO...


# 👇👽👍
Só joga na máquina e deixar instalar

• atualiza sistema

• desativa Ipv6

• instala recursos e o script


apt install wget -y; bash <(wget -qO- raw.githubusercontent.com/modderajuda/websocketsecurity/main/ssh-plus)

# PRO
